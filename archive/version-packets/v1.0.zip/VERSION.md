# v1.0 — 指定分类导出

读取真实店铺分类并按 cateId 抓取指定分类。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_指定分类导出器_Final_1.0.zip`
- Size: 46,516,956 bytes
- SHA256: `b819b9bc2488dac947c9521f1b0dd15175fe87138a72627b73fccfb01b1c9315`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
