# v1.1 — 多模式选择

增加分类/全店关键词/分类+关键词/指定ID或链接与第一版全局历史。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_智能筛选与全局去重_最终版_v1.1_2026-08-22.zip`
- Size: 46,769,707 bytes
- SHA256: `407963ff38e724c984480b727d42fa075a6ad61ad6aaad1e1fc0974610eb0485`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
