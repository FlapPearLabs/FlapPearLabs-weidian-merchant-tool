# v1.2 — 搜索语义与稳定性

关键词由 AND 修正为 OR，增加别名与顶层异常不闪退。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_关键词OR与稳定性修复_v1.2_2026-08-22.zip`
- Size: 46,694,844 bytes
- SHA256: `2152048abde495d5d420fdee7f750794a5586dec68d27bd53dd5b195d512f02e`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
