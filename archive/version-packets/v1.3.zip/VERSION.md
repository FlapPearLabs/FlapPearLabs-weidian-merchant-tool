# v1.3 — 干净上传文件

剥离模板说明和示例数据，上传表与辅助文件分离。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_清晰上传目录_最终版_v1.3_2026-08-22.zip`
- Size: 46,799,832 bytes
- SHA256: `40f93adf81b4fec7b9084bd84d9f3c940f469403dc0716e48abdb03c9b77d85c`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
