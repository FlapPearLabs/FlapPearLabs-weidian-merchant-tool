# v1.4 — 商城黄金契约

以真实成功导入表为准：31列表头、第二行数据、分类空、放置仓库、保留中文。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_已验证商城格式_最终版_v1.4_2026-08-22.zip`
- Size: 46,534,337 bytes
- SHA256: `dccf5b0d5db606b78d382629e961508493d952792dbc5d8ac8b50bd3b0146e45`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
