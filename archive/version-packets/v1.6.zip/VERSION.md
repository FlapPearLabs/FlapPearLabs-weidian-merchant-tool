# v1.6 — 真实 addTime

按 addTime 排序，并将轻量索引与详情/SKU/图片深抓分离。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_真实上架时间_最终版_v1.6_2026-08-22.zip`
- Size: 46,663,373 bytes
- SHA256: `30afc160ad01888cff56b79ed931a0665a568f2f1e28fc1fd63f601d23811fc8`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
