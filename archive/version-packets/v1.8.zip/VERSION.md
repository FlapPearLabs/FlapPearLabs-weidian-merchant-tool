# v1.8 — 请求预算控制

有限智能窗口、分类最新优先、长冷却、连续失败主动停止。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_低频防风控与分类最新_最终版_v1.8_2026-08-23.zip`
- Size: 46,812,636 bytes
- SHA256: `a9962b9b550862a2d1e5869d157b780001d6f6eedf69a7be042cd76fd9a224be`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
