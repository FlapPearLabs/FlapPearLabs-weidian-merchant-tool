# v1.9 — 五层实体去重

ID/SKU→硬规格→标题归一化→字符模糊→dHash，三态裁决，历史基线1721。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_商品级五层去重_最终版_v1.9_2026-08-23.zip`
- Size: 47,425,088 bytes
- SHA256: `4600be97673686ef4424060281c1c1a1a71840e6909b330338d106de1165a96d`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
