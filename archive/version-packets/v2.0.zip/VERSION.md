# v2.0 — 动态基线与规格根因修复

根据真实“规格已存在”失败修复重复最终规格；QA通过后历史向前推进。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_动态基线五层去重与规格修复_最终版_v2.0_2026-08-23.zip`
- Size: 47,429,856 bytes
- SHA256: `4f294c79b21c53c38c5980d3ecd1e8f2c04a3b082be7322e91a08306e1ef123c`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
