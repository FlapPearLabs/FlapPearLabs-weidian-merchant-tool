# v2.1 — 真正 N 个新品

持续向后核验直到凑够N个NEW_CONFIRMED；本轮会话基线挡住内部重复。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_真正增量与动态基线_最终版_v2.1_2026-08-23.zip`
- Size: 47,441,968 bytes
- SHA256: `8a502e91362b153cb521c184c9cd02773ccae6d1fbbec74f42523693d451fb05`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
