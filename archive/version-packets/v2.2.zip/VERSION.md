# v2.2 — 多目标模糊找货

自然语言目标→轻量模糊排序→翻页选号→深抓→五层去重。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_多目标模糊找货与五层去重_最终版_v2.2_2026-08-23.zip`
- Size: 47,447,743 bytes
- SHA256: `64eb00677add8abc777176a8eb048720b2f2e94322309a58e370db45a5e0c041`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
