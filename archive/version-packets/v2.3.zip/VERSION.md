# v2.3 — 分类路由与固定历史中心

高置信商品词段先路由真实分类；低置信全店兜底；历史移出版本目录。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_智能分类路由模糊找货与持久历史中心_最终版_v2.3_2026-08-23.zip`
- Size: 47,449,565 bytes
- SHA256: `ee557ebe12d3ceeb54cd6cb1eb9802f4cd64d261f77f174de6c6fc73993c1985`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
