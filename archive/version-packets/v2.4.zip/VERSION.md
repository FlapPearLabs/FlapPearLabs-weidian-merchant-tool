# v2.4 — 单屏选号 UX

TTY 原位刷新，非TTY回退；不触碰已验证搜索/路由/去重核心。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_单屏选号与持久历史中心_最终版_v2.4_2026-08-24.zip`
- Size: 47,451,043 bytes
- SHA256: `c65bae7fdd12cf49bbc233571c5b532c61f822f7de2f150116507f031be9fb8d`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
