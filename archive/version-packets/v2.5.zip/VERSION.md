# v2.5 — GitHub + SQLite

代码、可删运行包、持久业务状态三分离；一次性旧历史导入后永不扫描兄弟版本。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_GitHub加SQLite统一数据中心_正式版_v2.5_2026-08-24.zip`
- Size: 46,882,673 bytes
- SHA256: `4fbd543bfbaaef0e857e13ee39ab48f90df1ecdc0bc48146902782d8fcb1a60b`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
