# v2.6 — 健康账本与恢复

runs/export_batches、高水位、健康锚点、checkpoint、导入确认、恢复工具。

## Provenance

This packet records the identity and role of the formal local artifact used during project evolution. The ~47MB full runtime package is intentionally not committed because it duplicates Node/runtime dependencies and may contain local business-state artifacts.

- Local artifact: `商家工具_健康账本与按需增量_正式版_v2.6_2026-08-24.zip`
- Size: 46,896,284 bytes
- SHA256: `0719448c71f49e21bc390fd728be4ef1450e5ecc660079db3b8777ec23ea623c`

## Review path

Use this packet together with repository documents:

- `docs/PROJECT_EVOLUTION.md`
- `docs/DECISION_LOG.md`
- `docs/VALIDATION_EVIDENCE.md`
- current source on `main`

The `SOURCE_INDEX.json` file lists reviewable source/config files present in that historical release.
